/* =========================================================================
   0. CẤU HÌNH ĐƯỜNG LINK GOOGLE SHEETS (ĐỂ TRỐNG NẾU CHỈ DÙNG ẢNH TRONG CODE)
   ========================================================================= */
const GOOGLE_SHEET_API_URL = 'DAN_LINK_GOOGLE_APPS_SCRIPT_CUA_BAN_VAO_DAY';

// Danh sách kích cỡ áp dụng cho toàn bộ sản phẩm (đã bỏ Size S)
const AVAILABLE_SIZES = ['M', 'L', 'XL'];

/* =========================================================================
   1. DANH SÁCH 5 SẢN PHẨM CHÍNH THỨC CỦA ZENKENITH (ĐÃ GỘP 2 MÀU CHIẾN BINH)
   ========================================================================= */
const CATEGORY_LABELS = {
    'ALL': 'TẤT CẢ',
    'TOPS': 'ÁO THUN',
    'BOTTOMS': 'QUẦN DÀI',
    'ACCESSORIES': 'PHỤ KIỆN'
};

 const DEFAULT_PRODUCTS = [
    {
        id: 'zk-01',
        code: 'ZK-01 // QUẦN DÀI',
        name: 'QUẦN BARCELONA ỐNG RỘNG',
        category: 'BOTTOMS',
        price: 350000,
        gsm: 420,
        badge: 'MỚI RA MẮT',
        imgPrimary: 'images/0ee6591e-7af2-4741-ad9a-47142a45670f.jpg',
        imgSecondary: 'images/0ee6591e-7af2-4741-ad9a-47142a45670f.jpg',
        desc: 'Quần barcelona ống rộng cá tính, chất vải jean dày 420GSM wash đen khói kết hợp đường chỉ may nổi uốn cong tạo khối kiến trúc mạnh mẽ.'
    },
    {
        id: 'zk-02',
        code: 'ZK-02 // ÁO THUN',
        name: 'ÁO THUN BOXY ZENKENITH ĐỈNH NÚI ĐỎ ĐÔ',
        category: 'TOPS',
        price: 250000,
        gsm: 250,
        badge: 'MỚI RA MẮT',
        imgPrimary: 'images/8ee9cf44-cf3d-4c87-98ca-3296bc279487.jpg',
        imgSecondary: 'images/8ee9cf44-cf3d-4c87-98ca-3296bc279487.jpg',
        desc: 'Áo thun Form hộp rộng màu đỏ đô wash cổ điển, mặt trước in chữ ZENKENITH cùng đồ họa dãy núi tuyết, mặt sau in biểu tượng thanh kiếm chữ thập nổi bật.'
    },
    {
        id: 'zk-03',
        code: 'ZK-03 // ÁO THUN',
        name: 'ÁO THUN BARCELONA SỌC ĐỎ XANH ZENKENITH',
        category: 'TOPS',
        price: 300000,
        gsm: 250,
        badge: 'BẢN GIỚI HẠN',
        imgPrimary: 'images/04377484-3ace-4a25-a29c-59d1cd1e5a03.jpg',
        imgSecondary: 'images/04377484-3ace-4a25-a29c-59d1cd1e5a03.jpg',
        desc: 'Áo thun Form rộng phong cách jersey bóng đá phối sọc đỏ đô - xanh navy cùng họa tiết mạng nhện chìm, cổ chữ V và logo ZENKENITH phong cách Y2K.'
    },
    {
        id: 'zk-04',
        code: 'ZK-04 // ÁO THUN',
        name: 'ÁO THUN THE ODYSSEY',
        category: 'TOPS',
        price: 250000,
        gsm: 250,
        badge: '2 MÀU // ĐỎ & ĐEN',
        imgPrimary: 'images/d4af7102-7879-4fc0-9a9c-9e5801c5f52b.jpg',
        imgSecondary: 'images/d4af7102-7879-4fc0-9a9c-9e5801c5f52b.jpg',
        colors: [
            {
                name: 'Đỏ Đô',
                hex: '#7f1d1d',
                img: 'images/d4af7102-7879-4fc0-9a9c-9e5801c5f52b.jpg'
            },
            {
                name: 'Đen',
                hex: '#141414',
                img: 'images/e96a2edd-a655-4dcb-b797-eca8567a67d4.jpg'
            }
        ],
        desc: 'Áo thun cotton dày 340GSM may chỉ nổi tương phản với 2 phiên bản màu Đỏ Đô và Đen Wash. Mặt trước in đồ họa mũ giáp chiến binh cổ đại và mặt sau in dòng trích dẫn nghệ thuật.'
    },
    {
        id: 'zk-05',
        code: 'ZK-05 // ÁO THUN',
        name: 'ÁO THUN XƯỢC ZENKENITH',
        category: 'TOPS',
        price: 200000,
        gsm: 240,
        badge: 'MỚI RA MẮT',
        imgPrimary: 'images/ee785ce3-c978-4353-82dc-fdb8f738f62d.jpg',
        imgSecondary: 'images/ee785ce3-c978-4353-82dc-fdb8f738f62d.jpg',
        desc: 'Áo thun Form hộp màu trắng tinh tối giản mặt trước, điểm nhấn phía sau lưng là dòng chữ Zenkenith cách điệu phong cách thư pháp mềm mại.'
    }
];

let PRODUCTS = [...DEFAULT_PRODUCTS];

/* =========================================================================
   2. ĐỒNG BỘ SẢN PHẨM TỪ GOOGLE SHEETS (NẾU CÓ DÁN LINK)
   ========================================================================= */
async function loadProductsFromGoogleSheet() {
    if (!GOOGLE_SHEET_API_URL || GOOGLE_SHEET_API_URL.includes('DAN_LINK_GOOGLE_APPS_SCRIPT')) {
        return;
    }

    try {
        const res = await fetch(GOOGLE_SHEET_API_URL);
        if (!res.ok) throw new Error('Không thể kết nối Google Sheets');
        const sheetProducts = await res.json();

        if (Array.isArray(sheetProducts) && sheetProducts.length > 0) {
            PRODUCTS = sheetProducts;
            renderCatalog();
            showToast(`Đã đồng bộ ${PRODUCTS.length} sản phẩm từ Google Sheets.`);
        }
    } catch (err) {
        console.warn('Đang dùng dữ liệu trong code:', err);
    }
}

/* =========================================================================
   3. MEGA MENU DATA (Form COMISSUE)
   ========================================================================= */
const MEGA_MENU_DATA = {
    all: {
        highlights: [
            { label: 'Xem Tất Cả', action: "selectMegaFilter('ALL', '')" },
            { label: 'Hàng Mới Về', action: "selectMegaFilter('ALL', '')" },
            { label: 'Vải Dày Nhất', action: "selectMegaSort('gsm-desc')" }
        ],
        columns: [
            {
                title: 'Áo Thun',
                links: [
                    { label: 'Áo Thun Đỉnh Núi Đỏ Đô', action: "selectMegaFilter('TOPS', 'ĐỈNH NÚI')" },
                    { label: 'Áo Thun Jersey Sọc Đỏ Xanh', action: "selectMegaFilter('TOPS', 'JERSEY')" },
                    { label: 'Áo Thun Chiến Binh (Đỏ / Đen)', action: "selectMegaFilter('TOPS', 'CHIẾN BINH')" },
                    { label: 'Áo Thun Trắng Thư Pháp', action: "selectMegaFilter('TOPS', 'THƯ PHÁP')" }
                ]
            },
            {
                title: 'Quần Dài',
                links: [
                    { label: 'Quần Denim Ống Rộng Chỉ Cong', action: "selectMegaFilter('BOTTOMS', '')" }
                ]
            },
            {
                title: 'Phụ Kiện',
                links: [
                    { label: 'Tất Cả Phụ Kiện', action: "selectMegaFilter('ACCESSORIES', '')" },
                    { label: 'Phòng Đo Size 3D', action: "scrollToSection('#fit-lab')" }
                ]
            }
        ],
        feature: {
            title: 'Sản Phẩm',
            img: 'images/8ee9cf44-cf3d-4c87-98ca-3296bc279487.jpg',
            href: '#catalog'
        }
    },
    tops: {
        highlights: [
            { label: 'Tất Cả Áo Thun', action: "selectMegaFilter('TOPS', '')" },
            { label: 'Bản Giới Hạn', action: "selectMegaFilter('TOPS', 'JERSEY')" },
            { label: 'Giá Tốt Nhất', action: "selectMegaSort('price-asc')" }
        ],
        columns: [
            {
                title: 'Dòng Form Hộp (Boxy)',
                links: [
                    { label: 'Áo Thun Đỉnh Núi Đỏ Đô', action: "selectMegaFilter('TOPS', 'ĐỈNH NÚI')" },
                    { label: 'Áo Thun Trắng Thư Pháp', action: "selectMegaFilter('TOPS', 'THƯ PHÁP')" }
                ]
            },
            {
                title: 'Dòng Chiến Binh & Jersey',
                links: [
                    { label: 'Áo Thun Chiến Binh (Đỏ / Đen)', action: "selectMegaFilter('TOPS', 'CHIẾN BINH')" },
                    { label: 'Áo Thun Jersey Sọc Đỏ Xanh', action: "selectMegaFilter('TOPS', 'JERSEY')" }
                ]
            },
            {
                title: 'Hỗ Trợ Chọn Form',
                links: [
                    { label: 'Đo Size Theo Dáng Người', action: "scrollToSection('#fit-lab')" }
                ]
            }
        ],
        feature: {
            title: 'Áo Thun',
            img: 'images/e96a2edd-a655-4dcb-b797-eca8567a67d4.jpg',
            href: '#catalog'
        }
    },
    bottoms: {
        highlights: [
            { label: 'Tất Cả Quần Dài', action: "selectMegaFilter('BOTTOMS', '')" },
            { label: 'Tất Cả Phụ Kiện', action: "selectMegaFilter('ACCESSORIES', '')" }
        ],
        columns: [
            {
                title: 'Quần Dài',
                links: [
                    { label: 'Quần Denim Ống Rộng Chỉ Cong', action: "selectMegaFilter('BOTTOMS', '')" }
                ]
            },
            {
                title: 'Phụ Kiện',
                links: [
                    { label: 'Xem Danh Mục Phụ Kiện', action: "selectMegaFilter('ACCESSORIES', '')" }
                ]
            },
            {
                title: 'Hỗ Trợ Chọn Form',
                links: [
                    { label: 'Đo Size Theo Chiều Cao', action: "scrollToSection('#fit-lab')" }
                ]
            }
        ],
        feature: {
            title: 'Quần Dài',
            img: 'images/0ee6591e-7af2-4741-ad9a-47142a45670f.jpg',
            href: '#catalog'
        }
    },
    fitlab: {
        highlights: [
            { label: 'Đo Size Ngay', action: "scrollToSection('#fit-lab')" },
            { label: 'Đồng Bộ Size', action: "scrollToSection('#fit-lab'); applyRecommendedSizeToFilter();" }
        ],
        columns: [
            {
                title: 'Kiểu Form Rập',
                links: [
                    { label: 'Form Gọn Vừa Vặn (0.92)', action: "scrollToSection('#fit-lab'); setQuickFitAlpha(0.92);" },
                    { label: 'Form Hộp Chuẩn (1.08)', action: "scrollToSection('#fit-lab'); setQuickFitAlpha(1.08);" },
                    { label: 'Form Rộng Thụng (1.20)', action: "scrollToSection('#fit-lab'); setQuickFitAlpha(1.20);" }
                ]
            },
            {
                title: 'Thông Số Phân Tích',
                links: [
                    { label: 'Chiều Cao & Cân Nặng', action: "scrollToSection('#fit-lab')" },
                    { label: 'Độ Rộng Vai & Độ Đứng Vải', action: "scrollToSection('#fit-lab')" }
                ]
            },
            {
                title: 'Tiêu Chuẩn Vải',
                links: [
                    { label: 'Áo Thun 320–340GSM', action: "selectMegaFilter('TOPS', '')" },
                    { label: 'Quần Denim 420GSM', action: "selectMegaFilter('BOTTOMS', '')" }
                ]
            }
        ],
        feature: {
            title: 'Phòng Đo Size',
            img: 'images/d4af7102-7879-4fc0-9a9c-9e5801c5f52b.jpg',
            href: '#fit-lab'
        }
    },
    lookbook: {
        highlights: [
            { label: 'Lookbook 01', action: "scrollToSection('#lookbook')" },
            { label: 'Tĩnh Lặng Bê Tông', action: "scrollToSection('#lookbook')" }
        ],
        columns: [
            {
                title: 'Bản Phối Nổi Bật',
                links: [
                    { label: 'Bản Phối 01 // Lớp Vỏ Kỹ Thuật', action: "scrollToSection('#lookbook')" },
                    { label: 'Bản Phối 02 // Nỉ Chân Cua 480GSM', action: "scrollToSection('#lookbook')" }
                ]
            },
            {
                title: 'Sản Phẩm Nổi Bật',
                links: [
                    { label: 'Áo Thun Jersey Sọc Đỏ Xanh', action: "selectMegaFilter('TOPS', 'JERSEY')" },
                    { label: 'Quần Denim Ống Rộng Chỉ Cong', action: "selectMegaFilter('BOTTOMS', '')" }
                ]
            },
            {
                title: 'Hồ Sơ Lưu Trữ',
                links: [
                    { label: 'Bộ Sưu Tập Thu - Đông', action: "selectMegaFilter('ALL', '')" }
                ]
            }
        ],
        feature: {
            title: 'Tạp Chí 01',
            img: 'images/04377484-3ace-4a25-a29c-59d1cd1e5a03.jpg',
            href: '#lookbook'
        }
    }
};

function showMegaMenu(menuKey) {
    const wrapper = document.getElementById('siteNavWrapper');
    const panel = document.getElementById('megaMenuPanel');
    const content = document.getElementById('megaMenuContent');
    const data = MEGA_MENU_DATA[menuKey];
    if (!panel || !content || !data) return;

    if (wrapper) wrapper.classList.add('menu-active');

    document.querySelectorAll('.nav-trigger').forEach(el => {
        el.classList.toggle('text-[#1d4ed8]', el.dataset.menu === menuKey);
    });

    const highlightsHTML = `
        <div class="col-span-3 space-y-2 pr-4">
            ${data.highlights.map(item => `
                <button onclick="${item.action}; hideMegaMenu();" class="block text-left font-sans font-normal text-[23px] leading-snug tracking-tight text-zen-black hover:text-[#1d4ed8] smooth-ease">
                    ${item.label}
                </button>
            `).join('')}
        </div>
    `;

    const columnsHTML = data.columns.map(col => `
        <div class="col-span-2 space-y-2">
            <h4 class="font-sans font-bold text-[15px] text-zen-black">${col.title}</h4>
            <ul class="space-y-1.5 font-sans text-[13px] text-neutral-800">
                ${col.links.map(link => `
                    <li>
                        <button onclick="${link.action}; hideMegaMenu();" class="text-left hover:text-[#1d4ed8] smooth-ease">
                            ${link.label}
                        </button>
                    </li>
                `).join('')}
            </ul>
        </div>
    `).join('');

    const featureHTML = `
        <div class="col-span-3">
            <a href="${data.feature.href}" onclick="hideMegaMenu()" class="group block relative aspect-[4/3] overflow-hidden rounded-xl bg-neutral-900 shadow-md">
                <img src="${data.feature.img}" alt="${data.feature.title}" class="w-full h-full object-cover object-left group-hover:scale-105 smooth-ease">
                <div class="absolute inset-0 bg-black/25 group-hover:bg-black/15 smooth-ease flex items-center justify-center p-4 text-center">
                    <span class="font-display font-black text-2xl sm:text-3xl text-white tracking-tight drop-shadow-md">${data.feature.title}</span>
                </div>
            </a>
        </div>
    `;

    content.innerHTML = highlightsHTML + columnsHTML + featureHTML;
    panel.classList.add('is-open');
}

function hideMegaMenu() {
    const wrapper = document.getElementById('siteNavWrapper');
    const panel = document.getElementById('megaMenuPanel');
    if (wrapper) wrapper.classList.remove('menu-active');
    if (panel) panel.classList.remove('is-open');
    document.querySelectorAll('.nav-trigger').forEach(el => el.classList.remove('text-[#1d4ed8]'));
}

function toggleSearchBox(forceState) {
    const btn = document.getElementById('searchToggleBtn');
    const wrap = document.getElementById('inlineSearchWrap');
    const input = document.getElementById('searchInput');
    if (!btn || !wrap) return;

    const shouldOpen = typeof forceState === 'boolean' ? forceState : wrap.classList.contains('hidden');
    if (shouldOpen) {
        btn.classList.add('hidden');
        wrap.classList.remove('hidden');
        wrap.classList.add('flex');
        if (input) input.focus();
    } else {
        wrap.classList.add('hidden');
        wrap.classList.remove('flex');
        btn.classList.remove('hidden');
    }
}

function selectMegaFilter(category, keyword) {
    state.searchQuery = keyword;
    const searchInput = document.getElementById('searchInput');
    if (searchInput) searchInput.value = keyword;
    filterByCategory(category);
    scrollToSection('#catalog');
}

function selectMegaSort(sortVal) {
    state.searchQuery = '';
    const searchInput = document.getElementById('searchInput');
    if (searchInput) searchInput.value = '';
    filterByCategory('ALL');
    const sortSelect = document.getElementById('sortSelect');
    if (sortSelect) sortSelect.value = sortVal;
    handleSort(sortVal);
    scrollToSection('#catalog');
}

function setQuickFitAlpha(alphaVal) {
    const el = document.getElementById('fitAlpha');
    if (el) {
        el.value = alphaVal;
        calculateAlgorithmicFit();
    }
}

function scrollToSection(selector) {
    const el = document.querySelector(selector);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
}

/* =========================================================================
   4. GLOBAL STATE, CURRENCY FormATTER & TOAST HELPER
   ========================================================================= */
const state = {
    activeCategory: 'ALL',
    searchQuery: '',
    sortBy: 'featured',
    recommendedSize: 'L',
    selectedSizes: {},
    selectedColors: {},
    wishlist: [],
    cart: [],
    promoCode: null,
    promoRate: 0,
    currentFinalTotal: 0,
    modalProduct: null,
    modalSelectedSize: 'L',
    modalSelectedColorIndex: 0
};

function FormatVND(amount) {
    return new Intl.NumberFormat('vi-VN').format(Math.round(amount)) + '₫';
}

function showToast(message) {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = 'bg-zen-black text-white border border-white/20 px-4 py-3 rounded-sm shadow-xl font-mono text-xs flex items-center gap-3 pointer-events-auto smooth-ease translate-y-2 opacity-0';
    toast.innerHTML = `
        <span class="w-2 h-2 bg-zen-accent rounded-full"></span>
        <span>${message}</span>
    `;
    container.appendChild(toast);
    requestAnimationFrame(() => {
        toast.classList.remove('translate-y-2', 'opacity-0');
    });
    setTimeout(() => {
        toast.classList.add('translate-y-2', 'opacity-0');
        setTimeout(() => toast.remove(), 450);
    }, 3200);
}

/* =========================================================================
   5. PHÒNG ĐO Form DÁNG THUẬT TOÁN (CHỈ ĐỀ XUẤT CỠ M / L / XL)
   ========================================================================= */
function calculateAlgorithmicFit() {
    const hEl = document.getElementById('fitHeight');
    const wEl = document.getElementById('fitWeight');
    const sEl = document.getElementById('fitShoulder');
    const aEl = document.getElementById('fitAlpha');
    if (!hEl || !wEl || !sEl || !aEl) return;

    const H = parseFloat(hEl.value);
    const W = parseFloat(wEl.value);
    const S = parseFloat(sEl.value);
    const alpha = parseFloat(aEl.value);

    const setTxt = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.textContent = val;
    };
    const setBar = (id, pct) => {
        const el = document.getElementById(id);
        if (el) el.style.width = Math.max(0, Math.min(100, pct)) + '%';
    };

    setTxt('valHeight', H + ' cm');
    setTxt('valWeight', W + ' kg');
    setTxt('valShoulder', S + ' cm');

    setBar('barHeight', ((H - 150) / (195 - 150)) * 100);
    setBar('barWeight', ((W - 42) / (110 - 42)) * 100);
    setBar('barShoulder', ((S - 38) / (58 - 38)) * 100);
    setBar('barAlpha', ((alpha - 0.90) / (1.25 - 0.90)) * 100);

    let styleLabel = 'Form Hộp Chuẩn';
    if (alpha < 0.98) styleLabel = 'Gọn Vừa Vặn';
    else if (alpha > 1.15) styleLabel = 'Rộng Thụng Đường Phố';
    setTxt('valAlpha', alpha.toFixed(2) + ' (' + styleLabel + ')');

    const GSM = 360;
    let fitScore, drapeIndex;
    try {
        if (typeof math !== 'undefined' && typeof math.evaluate === 'function') {
            const scope = { H, W, S, alpha, GSM };
            fitScore = math.evaluate('(W / sqrt(H * S)) * alpha + 0.12 * (S / 45)^2', scope);
            drapeIndex = math.evaluate('(GSM / 300) * log(1 + (H * S) / 1000) * (alpha ^ -0.5)', scope);
        } else {
            throw new Error('fallback');
        }
    } catch (err) {
        fitScore = (W / Math.sqrt(H * S)) * alpha + 0.12 * Math.pow(S / 45, 2);
        drapeIndex = (GSM / 300) * Math.log(1 + (H * S) / 1000) * Math.pow(alpha, -0.5);
    }

    setTxt('fitScoreOutput', fitScore.toFixed(3));
    setTxt('drapeScoreOutput', drapeIndex.toFixed(3));

    const sizeIndex = fitScore + (H - 170) * 0.008;
    let size = 'M';
    let specs = { length: 71, chest: 61, shoulder: 55 };

    if (sizeIndex < 0.93) {
        size = 'M';
        specs = { length: 71, chest: 61, shoulder: 55 };
    } else if (sizeIndex < 1.07) {
        size = 'L';
        specs = { length: 74, chest: 64, shoulder: 58 };
    } else {
        size = 'XL';
        specs = { length: 77, chest: 67, shoulder: 61 };
    }

    state.recommendedSize = size;
    setTxt('recommendedSizeDisplay', 'CỠ ' + size);
    setTxt('recommendedFitDesc', styleLabel + ' // Tỷ lệ vai ' + (S / specs.shoulder).toFixed(2));
    setTxt('specLength', specs.length + ' cm');
    setTxt('specChest', specs.chest + ' cm');
    setTxt('specShoulder', specs.shoulder + ' cm');
}

/* =========================================================================
   6. PRODUCT CATALOG RENDER, FILTERING & SORTING
   ========================================================================= */
function renderCatalog() {
    const grid = document.getElementById('productGrid');
    if (!grid) return;

    const allBtn = document.querySelector('.cat-btn[data-cat="ALL"]');
    if (allBtn) allBtn.textContent = `Tất cả (${PRODUCTS.length})`;

    let filtered = PRODUCTS.filter(p => {
        const prodCat = String(p.category || '').trim().toUpperCase();
        const matchesCat = state.activeCategory === 'ALL' || prodCat === state.activeCategory;
        const matchesSearch = String(p.name || '').toLowerCase().includes(state.searchQuery.toLowerCase()) ||
                              String(p.code || '').toLowerCase().includes(state.searchQuery.toLowerCase());
        return matchesCat && matchesSearch;
    });

    if (state.sortBy === 'price-asc') {
        filtered.sort((a, b) => a.price - b.price);
    } else if (state.sortBy === 'price-desc') {
        filtered.sort((a, b) => b.price - a.price);
    } else if (state.sortBy === 'gsm-desc') {
        filtered.sort((a, b) => b.gsm - a.gsm);
    }

    if (filtered.length === 0) {
        grid.innerHTML = `
            <div class="col-span-full py-20 text-center font-mono text-sm uppercase tracking-widest text-neutral-500 border border-dashed border-neutral-300 rounded-sm bg-white">
                Không có sản phẩm
            </div>
        `;
        return;
    }

    grid.innerHTML = filtered.map(product => {
        const rawSize = state.selectedSizes[product.id] || state.recommendedSize || 'L';
        const currentSize = AVAILABLE_SIZES.includes(rawSize) ? rawSize : 'M';
        const isWishlisted = state.wishlist.includes(product.id);

        const hasColors = Array.isArray(product.colors) && product.colors.length > 0;
        const colorIdx = state.selectedColors[product.id] || 0;
        const activeImg = hasColors ? product.colors[colorIdx].img : product.imgPrimary;
        const secondaryImg = hasColors ? product.colors[colorIdx].img : (product.imgSecondary || product.imgPrimary);

        const colorDotsHTML = hasColors ? `
            <div class="flex items-center gap-2 mt-2">
                <span class="font-mono text-[10px] text-neutral-500 uppercase">Màu:</span>
                ${product.colors.map((c, idx) => `
                    <button onclick="event.stopPropagation(); selectCardColor('${product.id}', ${idx})"
                            title="${c.name}"
                            class="w-4 h-4 rounded-full border smooth-ease ${colorIdx === idx ? 'ring-2 ring-offset-1 ring-zen-black border-white scale-110' : 'border-neutral-400 opacity-80 hover:opacity-100'}"
                            style="background-color: ${c.hex};"></button>
                `).join('')}
                <span class="font-mono text-[10px] font-bold text-zen-black">${product.colors[colorIdx].name}</span>
            </div>
        ` : '';

        return `
            <article class="product-card group flex flex-col justify-between">
                <div>
                    <div class="relative aspect-[4/5] bg-neutral-200 overflow-hidden rounded-sm border border-zen-black/10 mb-4 cursor-pointer" onclick="openProductModal('${product.id}')">
                        <img src="${activeImg}" 
                             onerror="this.src='https://placehold.co/600x750/141414/ffffff?text=ZENKENITH'"
                             alt="${product.name}" 
                             class="primary-img w-full h-full object-cover object-left">
                        <img src="${secondaryImg}" 
                             onerror="this.src='https://placehold.co/600x750/262626/ffffff?text=GOC+NHIN+02'"
                             alt="${product.name} mặt sau" 
                             class="secondary-img absolute inset-0 w-full h-full object-cover object-right">

                        <div class="absolute top-3 left-3 right-3 flex justify-between items-center pointer-events-none">
                            <span class="bg-zen-black text-white font-mono text-[10px] uppercase tracking-wider px-2.5 py-1 rounded-sm">${product.badge || 'MỚI'}</span>
                            <span class="bg-white/90 backdrop-blur-xs text-zen-black font-mono text-[10px] font-bold px-2 py-0.5 rounded-sm">${product.gsm} GSM</span>
                        </div>

                        <button onclick="event.stopPropagation(); toggleWishlist('${product.id}')" class="absolute bottom-3 right-3 bg-white/90 hover:bg-zen-black hover:text-white text-zen-black w-8 h-8 rounded-sm flex items-center justify-center smooth-ease" aria-label="Lưu yêu thích">
                            <i class="${isWishlisted ? 'fa-solid' : 'fa-regular'} fa-bookmark text-xs"></i>
                        </button>
                    </div>

                    <div class="flex justify-between items-start font-mono text-[10px] text-neutral-500 mb-1">
                        <span>${product.code}</span>
                        <span>Form HỘP RỘNG</span>
                    </div>
                    <h3 onclick="openProductModal('${product.id}')" class="font-display font-black text-base uppercase tracking-tight cursor-pointer hover:underline">${product.name}</h3>
                    <div class="font-mono text-sm font-semibold mt-1">${FormatVND(product.price)}</div>
                    ${colorDotsHTML}
                </div>

                <div class="mt-4 pt-3 border-t border-neutral-200 space-y-2">
                    <div class="grid grid-cols-3 gap-1 font-mono text-[11px]">
                        ${AVAILABLE_SIZES.map(sz => `
                            <button onclick="selectCardSize('${product.id}', '${sz}')" 
                                    class="py-1 border rounded-sm smooth-ease ${currentSize === sz ? 'bg-zen-black text-white border-zen-black font-bold' : 'bg-white text-neutral-700 border-neutral-300 hover:border-zen-black'}">
                                ${sz}
                            </button>
                        `).join('')}
                    </div>
                    <button onclick="handleCardAddToCart('${product.id}', '${currentSize}')" class="w-full bg-zen-black text-white font-mono text-[11px] uppercase tracking-widest py-2.5 rounded-sm hover:bg-neutral-800 smooth-ease flex items-center justify-center gap-2">
                        <span>${hasColors ? '+ CHỌN MÀU & THÊM GIỎ' : '+ THÊM VÀO GIỎ (CỠ ' + currentSize + ')'}</span>
                    </button>
                </div>
            </article>
        `;
    }).join('');
}

function selectCardColor(productId, colorIdx) {
    state.selectedColors[productId] = colorIdx;
    renderCatalog();
}

function selectCardSize(productId, size) {
    state.selectedSizes[productId] = size;
    renderCatalog();
}

function handleCardAddToCart(productId, size) {
    const product = PRODUCTS.find(p => p.id === productId);
    if (!product) return;

    if (Array.isArray(product.colors) && product.colors.length > 0) {
        state.selectedSizes[productId] = size;
        openProductModal(productId);
        return;
    }

    addToCart(productId, size, null);
}

function filterByCategory(category) {
    state.activeCategory = category;
    document.querySelectorAll('.cat-btn').forEach(btn => {
        if (btn.dataset.cat === category) {
            btn.className = 'cat-btn bg-zen-black text-white px-4 py-2 rounded-sm uppercase tracking-wider smooth-ease';
        } else {
            btn.className = 'cat-btn bg-white border border-neutral-300 text-zen-black px-4 py-2 rounded-sm uppercase tracking-wider hover:border-zen-black smooth-ease';
        }
    });
    renderCatalog();
}

function handleSearch(query) {
    state.searchQuery = query.trim();
    renderCatalog();
}

function handleSort(sortVal) {
    state.sortBy = sortVal;
    renderCatalog();
}

function toggleWishlist(productId) {
    const idx = state.wishlist.indexOf(productId);
    if (idx === -1) {
        state.wishlist.push(productId);
        showToast('Đã lưu sản phẩm vào danh sách yêu thích.');
    } else {
        state.wishlist.splice(idx, 1);
        showToast('Đã bỏ sản phẩm khỏi danh sách yêu thích.');
    }
    document.getElementById('wishlistCount').textContent = state.wishlist.length;
    renderCatalog();
}

function applyRecommendedSizeToFilter() {
    PRODUCTS.forEach(p => {
        state.selectedSizes[p.id] = state.recommendedSize;
    });
    renderCatalog();
    showToast(`Đã đồng bộ toàn bộ sản phẩm sang CỠ ${state.recommendedSize}.`);
}

/* =========================================================================
   7. PRODUCT DETAIL MODAL (CHỌN MÀU & CỠ M / L / XL)
   ========================================================================= */
function ensureModalColorSection() {
    let colorSection = document.getElementById('modalColorSection');
    if (colorSection) return colorSection;

    const sizeButtonsEl = document.getElementById('modalSizeButtons');
    if (!sizeButtonsEl || !sizeButtonsEl.parentElement) return null;

    colorSection = document.createElement('div');
    colorSection.id = 'modalColorSection';
    colorSection.className = 'space-y-2.5 hidden';
    colorSection.innerHTML = `
        <div class="flex justify-between font-mono text-xs">
            <span class="uppercase font-bold">CHỌN MÀU SẮC:</span>
            <span id="modalSelectedColorLabel" class="font-bold text-zen-black uppercase">ĐỎ ĐÔ</span>
        </div>
        <div id="modalColorButtons" class="grid grid-cols-2 gap-2.5 font-mono text-xs"></div>
    `;

    sizeButtonsEl.parentElement.parentNode.insertBefore(colorSection, sizeButtonsEl.parentElement);
    return colorSection;
}

function openProductModal(productId) {
    const product = PRODUCTS.find(p => p.id === productId);
    if (!product) return;

    state.modalProduct = product;
    const rawSize = state.selectedSizes[productId] || state.recommendedSize || 'L';
    state.modalSelectedSize = AVAILABLE_SIZES.includes(rawSize) ? rawSize : 'M';
    state.modalSelectedColorIndex = state.selectedColors[productId] || 0;

    const hasColors = Array.isArray(product.colors) && product.colors.length > 0;
    const activeImg = hasColors ? product.colors[state.modalSelectedColorIndex].img : product.imgPrimary;

    const modalImg = document.getElementById('modalProductImg');
    modalImg.src = activeImg;
    modalImg.className = 'w-full h-full object-contain bg-[#d4d4d8]';

    document.getElementById('modalProductCode').textContent = product.code;
    document.getElementById('modalProductBadge').textContent = product.badge || 'MỚI';
    document.getElementById('modalProductCategory').textContent = CATEGORY_LABELS[product.category] || product.category;
    document.getElementById('modalProductName').textContent = product.name;
    document.getElementById('modalProductPrice').textContent = FormatVND(product.price);
    document.getElementById('modalProductDesc').textContent = product.desc;
    document.getElementById('modalProductGsm').textContent = product.gsm + ' GSM';
    document.getElementById('modalSuggestedSize').textContent = 'CỠ ' + state.recommendedSize;

    const colorSection = ensureModalColorSection();
    if (colorSection) {
        if (hasColors) {
            colorSection.classList.remove('hidden');
            renderModalColorButtons();
        } else {
            colorSection.classList.add('hidden');
        }
    }

    renderModalSizeButtons();

    document.getElementById('modalAddToCartBtn').onclick = () => {
        const chosenColor = hasColors ? product.colors[state.modalSelectedColorIndex] : null;
        addToCart(product.id, state.modalSelectedSize, chosenColor);
        closeProductModal();
    };

    document.getElementById('productModal').classList.remove('hidden');
}

function renderModalColorButtons() {
    const product = state.modalProduct;
    if (!product || !Array.isArray(product.colors)) return;

    const container = document.getElementById('modalColorButtons');
    const label = document.getElementById('modalSelectedColorLabel');
    const selectedColor = product.colors[state.modalSelectedColorIndex];

    if (label && selectedColor) {
        label.textContent = selectedColor.name;
    }

    container.innerHTML = product.colors.map((c, idx) => `
        <button type="button" onclick="selectModalColor(${idx})"
                class="flex items-center justify-center gap-2 py-2.5 px-3 border rounded-sm uppercase font-mono smooth-ease ${state.modalSelectedColorIndex === idx ? 'bg-zen-black text-white border-zen-black font-bold' : 'bg-white text-zen-black border-neutral-300 hover:border-zen-black'}">
            <span class="w-3.5 h-3.5 rounded-full border border-white/60 inline-block" style="background-color: ${c.hex};"></span>
            <span>${c.name}</span>
        </button>
    `).join('');
}

function selectModalColor(colorIdx) {
    const product = state.modalProduct;
    if (!product || !Array.isArray(product.colors) || !product.colors[colorIdx]) return;

    state.modalSelectedColorIndex = colorIdx;
    state.selectedColors[product.id] = colorIdx;

    const modalImg = document.getElementById('modalProductImg');
    if (modalImg) modalImg.src = product.colors[colorIdx].img;

    renderModalColorButtons();
    renderCatalog();
}

function renderModalSizeButtons() {
    const container = document.getElementById('modalSizeButtons');
    container.className = 'grid grid-cols-3 gap-2 font-mono text-xs';
    container.innerHTML = AVAILABLE_SIZES.map(sz => `
        <button type="button" onclick="state.modalSelectedSize = '${sz}'; renderModalSizeButtons();"
                class="py-2.5 border rounded-sm uppercase font-mono smooth-ease ${state.modalSelectedSize === sz ? 'bg-zen-black text-white border-zen-black font-bold' : 'bg-white text-zen-black border-neutral-300'}">
            CỠ ${sz}
        </button>
    `).join('');
}

function closeProductModal() {
    document.getElementById('productModal').classList.add('hidden');
}

/* =========================================================================
   8. GIỎ HÀNG & GỬI ĐƠN HÀNG VỀ GOOGLE SHEETS
   ========================================================================= */
function addToCart(productId, size, colorObj = null) {
    const product = PRODUCTS.find(p => p.id === productId);
    if (!product) return;

    const colorName = colorObj ? colorObj.name : '';
    const itemImg = colorObj ? colorObj.img : product.imgPrimary;

    const existing = state.cart.find(item =>
        item.id === productId &&
        item.size === size &&
        (item.color || '') === colorName
    );

    if (existing) {
        existing.qty += 1;
    } else {
        state.cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            size: size,
            color: colorName,
            qty: 1,
            img: itemImg
        });
    }

    updateCartUI();
    const colorNote = colorName ? ` - Màu ${colorName}` : '';
    showToast(`Đã thêm ${product.name} (Cỡ ${size}${colorNote}) vào giỏ hàng.`);
}

function updateCartQty(index, delta) {
    state.cart[index].qty += delta;
    if (state.cart[index].qty <= 0) {
        state.cart.splice(index, 1);
    }
    updateCartUI();
}

function applyPromoCode() {
    const code = document.getElementById('promoCodeInput').value.trim().toUpperCase();
    if (code === 'ZEN10') {
        state.promoCode = 'ZEN10';
        state.promoRate = 0.10;
        showToast('Đã áp dụng mã ZEN10 (Giảm thêm 10% tổng giá trị đơn hàng).');
    } else {
        state.promoCode = null;
        state.promoRate = 0;
        showToast('Mã giảm giá không hợp lệ. Vui lòng thử mã: ZEN10');
    }
    updateCartUI();
}

function updateCartUI() {
    const totalItems = state.cart.reduce((sum, item) => sum + item.qty, 0);
    document.getElementById('cartCountBadge').textContent = totalItems;
    document.getElementById('drawerCartCount').textContent = totalItems;

    const container = document.getElementById('cartItemsContainer');
    if (state.cart.length === 0) {
        container.innerHTML = `
            <div class="h-64 flex flex-col items-center justify-center text-center font-mono text-xs text-neutral-400">
                <i class="fa-solid fa-bag-shopping text-2xl mb-3"></i>
                <span>GIỎ HÀNG CỦA BẠN ĐANG TRỐNG.</span>
            </div>
        `;
    } else {
        container.innerHTML = state.cart.map((item, idx) => `
            <div class="flex gap-4 bg-white p-3.5 border border-neutral-200 rounded-sm smooth-ease">
                <img src="${item.img}" alt="${item.name}" class="w-16 h-20 object-cover object-left bg-neutral-100 rounded-sm">
                <div class="flex-1 flex flex-col justify-between font-mono text-xs">
                    <div>
                        <div class="font-bold uppercase leading-tight">${item.name}</div>
                        <div class="text-[10px] text-neutral-500 mt-0.5">
                            KÍCH CỠ: ${item.size}${item.color ? ' // MÀU: ' + item.color.toUpperCase() : ''}
                        </div>
                    </div>
                    <div class="flex items-center justify-between pt-2">
                        <div class="flex items-center border border-neutral-300 rounded-sm">
                            <button onclick="updateCartQty(${idx}, -1)" class="px-2 py-0.5 hover:bg-neutral-100 smooth-ease">-</button>
                            <span class="px-2.5">${item.qty}</span>
                            <button onclick="updateCartQty(${idx}, 1)" class="px-2 py-0.5 hover:bg-neutral-100 smooth-ease">+</button>
                        </div>
                        <span class="font-bold">${FormatVND(item.price * item.qty)}</span>
                    </div>
                </div>
            </div>
        `).join('');
    }

    const subtotal = state.cart.reduce((sum, item) => sum + item.price * item.qty, 0);
    let discountRate, discountAmount, afterDiscount, finalTotal;

    try {
        if (typeof math !== 'undefined' && typeof math.evaluate === 'function') {
            const bundleRateExpr = totalItems >= 2 ? `min(0.22, 0.03 * ${totalItems} + ${state.promoRate})` : `${state.promoRate}`;
            discountRate = math.evaluate(bundleRateExpr);
            discountAmount = math.evaluate(`${subtotal} * ${discountRate}`);
            afterDiscount = math.evaluate(`${subtotal} - ${discountAmount}`);
        } else {
            throw new Error('fallback');
        }
    } catch (err) {
        discountRate = totalItems >= 2 ? Math.min(0.22, 0.03 * totalItems + state.promoRate) : state.promoRate;
        discountAmount = subtotal * discountRate;
        afterDiscount = subtotal - discountAmount;
    }

    const shipping = (afterDiscount >= 1500000 || afterDiscount === 0) ? 0 : 35000;
    finalTotal = afterDiscount + shipping;
    state.currentFinalTotal = finalTotal;

    document.getElementById('cartSubtotal').textContent = FormatVND(subtotal);
    document.getElementById('bundleDiscountLabel').textContent = `CHIẾT KHẤU (${Math.round(discountRate * 100)}%):`;
    document.getElementById('cartDiscount').textContent = `-${FormatVND(discountAmount)}`;
    document.getElementById('cartShipping').textContent = shipping === 0 ? 'MIỄN PHÍ' : FormatVND(shipping);
    document.getElementById('cartTotal').textContent = FormatVND(finalTotal);
}

function toggleCartDrawer(open) {
    const drawer = document.getElementById('cartDrawer');
    const backdrop = document.getElementById('cartDrawerBackdrop');
    if (open) {
        backdrop.classList.remove('hidden');
        drawer.classList.remove('translate-x-full');
    } else {
        backdrop.classList.add('hidden');
        drawer.classList.add('translate-x-full');
    }
}

function handleCheckout() {
    if (state.cart.length === 0) {
        showToast('Giỏ hàng đang trống. Vui lòng chọn sản phẩm trước khi đặt hàng.');
        return;
    }
    toggleCartDrawer(false);
    document.getElementById('checkoutSummaryTotal').textContent = FormatVND(state.currentFinalTotal);
    document.getElementById('checkoutModal').classList.remove('hidden');
}

function closeCheckoutModal() {
    document.getElementById('checkoutModal').classList.add('hidden');
}

async function submitOrderToSheet(e) {
    e.preventDefault();
    const btn = document.getElementById('submitOrderBtn');
    btn.disabled = true;
    btn.textContent = 'ĐANG GỬI ĐƠN HÀNG...';

    const orderCode = 'ZK-' + Math.floor(100000 + Math.random() * 900000);
    const itemsText = state.cart.map(i => {
        const variant = i.color ? `${i.color} - Cỡ ${i.size}` : `Cỡ ${i.size}`;
        return `${i.name} (${variant}) x${i.qty}`;
    }).join(' | ');

    const payload = {
        orderCode,
        customerName: document.getElementById('custName').value.trim(),
        phone: document.getElementById('custPhone').value.trim(),
        address: document.getElementById('custAddress').value.trim(),
        itemsText,
        total: FormatVND(state.currentFinalTotal)
    };

    try {
        if (GOOGLE_SHEET_API_URL && !GOOGLE_SHEET_API_URL.includes('DAN_LINK_GOOGLE_APPS_SCRIPT')) {
            await fetch(GOOGLE_SHEET_API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                body: JSON.stringify(payload)
            });
        }
        state.cart = [];
        updateCartUI();
        document.getElementById('checkoutForm').reset();
        closeCheckoutModal();
        showToast(`Đặt hàng thành công! Mã đơn của bạn: ${orderCode}`);
    } catch (err) {
        showToast('Có lỗi khi gửi đơn hàng. Vui lòng thử lại.');
    } finally {
        btn.disabled = false;
        btn.textContent = 'XÁC NHẬN ĐẶT HÀNG';
    }
}

function toggleMobileMenu() {
    document.getElementById('mobileMenu').classList.toggle('hidden');
}

/* =========================================================================
   9. HERO INTERACTIVE FABRIC MESH CANVAS
   ========================================================================= */
function initHeroCanvas() {
    const canvas = document.getElementById('heroCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let width, height;
    let targetMouse = { x: -1000, y: -1000 };
    let smoothMouse = { x: -1000, y: -1000 };
    let tick = 0;

    function resize() {
        const rect = canvas.parentElement.getBoundingClientRect();
        width = canvas.width = rect.width;
        height = canvas.height = rect.height;
    }

    window.addEventListener('resize', resize);
    resize();

    canvas.addEventListener('mousemove', (e) => {
        const rect = canvas.getBoundingClientRect();
        targetMouse.x = e.clientX - rect.left;
        targetMouse.y = e.clientY - rect.top;
        if (smoothMouse.x < -500) {
            smoothMouse.x = targetMouse.x;
            smoothMouse.y = targetMouse.y;
        }
        const coordsEl = document.getElementById('canvasCoords');
        if (coordsEl) {
            coordsEl.textContent = `X:${String(Math.round(targetMouse.x)).padStart(3, '0')} Y:${String(Math.round(targetMouse.y)).padStart(3, '0')}`;
        }
    });

    canvas.addEventListener('mouseleave', () => {
        targetMouse.x = -1000;
        targetMouse.y = -1000;
    });

    canvas.addEventListener('touchmove', (e) => {
        if (e.touches.length > 0) {
            const rect = canvas.getBoundingClientRect();
            targetMouse.x = e.touches[0].clientX - rect.left;
            targetMouse.y = e.touches[0].clientY - rect.top;
        }
    }, { passive: true });

    function animateHero() {
        ctx.clearRect(0, 0, width, height);
        tick += 0.015;

        smoothMouse.x += (targetMouse.x - smoothMouse.x) * 0.12;
        smoothMouse.y += (targetMouse.y - smoothMouse.y) * 0.12;

        const cols = Math.floor(width / 42);
        const rows = Math.floor(height / 42);
        const spacingX = width / (cols || 1);
        const spacingY = height / (rows || 1);

        ctx.strokeStyle = 'rgba(255, 255, 255, 0.13)';
        ctx.lineWidth = 1;

        const points = [];
        for (let r = 0; r <= rows; r++) {
            points[r] = [];
            for (let c = 0; c <= cols; c++) {
                let px = c * spacingX;
                let py = r * spacingY;

                const wave = Math.sin(c * 0.32 + tick) * 6.5 + Math.cos(r * 0.32 + tick) * 6.5;
                const dx = px - smoothMouse.x;
                const dy = py - smoothMouse.y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                const maxRadius = 175;
                let pushX = 0;
                let pushY = 0;

                if (dist < maxRadius && dist > 0) {
                    const falloff = Math.pow(1 - dist / maxRadius, 2);
                    const force = falloff * 28;
                    pushX = (dx / dist) * force;
                    pushY = (dy / dist) * force;
                }

                points[r][c] = { x: px + pushX, y: py + wave + pushY };
            }
        }

        for (let r = 0; r <= rows; r++) {
            ctx.beginPath();
            for (let c = 0; c <= cols; c++) {
                const pt = points[r][c];
                if (c === 0) ctx.moveTo(pt.x, pt.y);
                else ctx.lineTo(pt.x, pt.y);
            }
            ctx.stroke();
        }

        for (let c = 0; c <= cols; c++) {
            ctx.beginPath();
            for (let r = 0; r <= rows; r++) {
                const pt = points[r][c];
                if (r === 0) ctx.moveTo(pt.x, pt.y);
                else ctx.lineTo(pt.x, pt.y);
            }
            ctx.stroke();
        }

        for (let r = 0; r <= rows; r++) {
            for (let c = 0; c <= cols; c++) {
                const pt = points[r][c];
                const dist = Math.hypot(pt.x - smoothMouse.x, pt.y - smoothMouse.y);
                if (dist < 135) {
                    ctx.fillStyle = '#d4ff00';
                    ctx.fillRect(pt.x - 2, pt.y - 2, 4, 4);
                }
            }
        }

        requestAnimationFrame(animateHero);
    }

    animateHero();
}

/* =========================================================================
   10. KHỞI CHẠY ỨNG DỤNG
   ========================================================================= */
document.addEventListener('DOMContentLoaded', () => {
    renderCatalog();
    calculateAlgorithmicFit();
    updateCartUI();
    initHeroCanvas();
    loadProductsFromGoogleSheet();

    ['fitHeight', 'fitWeight', 'fitShoulder', 'fitAlpha'].forEach(id => {
        const slider = document.getElementById(id);
        if (slider) {
            slider.addEventListener('input', calculateAlgorithmicFit);
            slider.addEventListener('change', calculateAlgorithmicFit);
        }
    });
});